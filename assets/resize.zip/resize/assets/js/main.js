jQuery(document).ready(function () {
    $("#download").hide();
})
$.cloudinary.config({ cloud_name: 'pinfoot', secure: true });
var image = "";
$('#upload_widget_opener').cloudinary_upload_widget(
    { cloud_name: 'pinfoot', upload_preset: 'txzq1tsf', sources: ["local", "url", "camera", "facebook", "instagram", "google_photos"], multiple: false, folder: "ccc", resource_type: "image", theme: "white", thumbnails: ".img", button_class: "select-button" },
    function (error, result) {
        if (error) {
            alert("an error occured");
        } else {
            image = "ccc:" + result[0].public_id.substring(4) + "." + result[0].format;
            $("#img").attr("src", result[0].secure_url);
            var img = $.cloudinary.image("platform_swo1om.png", {
                transformation: [
                    { overlay: image, width: 241, height: 513 }
                ]
            });
            console.log(img);
            $("#download").attr("href", img[0].src);
            $("#img").attr("src", img[0].src);
            $("#download").show();
            // localStorage.setItem("picture", img[0].src);
            // var win = window.open("final", '_blank').location;
            console.log(img[0].src);

        }
        console.log(error);
        console.log(error, result);

    });